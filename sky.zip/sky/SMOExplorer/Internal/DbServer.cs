﻿using ICSharpCode.Core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace SMOExplorer.Internal
{
	public class DbServer
	{
		static string version = "1.0";
		static string DbServerFileName = "DbServer.xml";
		static List<DbServer> dbServers = new List<DbServer>();

		public static List<DbServer> DbServers
		{
			get
			{
				return dbServers;
			}
		}

		static bool LoadServers(string fileName)
		{
			if (!File.Exists(fileName))
			{
				return false;
			}

			XmlDocument doc = new XmlDocument();
			try
			{
				doc.Load(fileName);

				if (doc.DocumentElement.GetAttribute("version") != version)
				{
					return false;
				}

				foreach (XmlElement el in doc.DocumentElement.ChildNodes)
				{
					DbServers.Add(new DbServer(el));
				}
			}
			catch (Exception)
			{
				return false;
			}
			return true;
		}

		static DbServer()
		{
			if (!LoadServers(Path.Combine(PropertyService.DataDirectory, "sky", "SMOExplorer", DbServerFileName)))
			{
				MessageService.ShowWarning("Can not load db servers");
			}
		}

		#region DbServer
		private string name;
		private string serverName;

		public DbServer(XmlElement el)
		{
			this.name = el.GetAttribute("name");
			this.serverName = el.GetAttribute("serverName");
		}

		public override string ToString()
		{
			return name;
		}

		#endregion
	}

}
