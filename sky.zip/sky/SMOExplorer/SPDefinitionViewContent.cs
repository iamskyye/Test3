﻿using ICSharpCode.SharpDevelop.Workbench;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMOExplorer
{
	public class SPDefinitionViewContent : AbstractViewContent
	{
		SPDefinitionControl content = new SPDefinitionControl();

		public override object Control
		{
			get
			{
				return content;
			}
		}

		public SPDefinitionViewContent()
		{
			SetLocalizedTitle("SP Definition");
		}
	}
}
