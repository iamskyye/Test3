﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SMOExplorer.Internal;

namespace SMOExplorer
{
	public partial class SPDefinitionControl : UserControl
	{
		public SPDefinitionControl()
		{
			InitializeComponent();
			LoadControls();

		}

		private void LoadControls()
		{
			foreach (DbServer dbServer in DbServer.DbServers)
			{
				dbServerChooser.Items.Add(dbServer);
			}
			dbServerChooser.SelectedIndex = 0;
		}

		private void button1_Click(object sender, EventArgs e)
		{
			MessageBox.Show("LOVE!");
		}
	}
}
