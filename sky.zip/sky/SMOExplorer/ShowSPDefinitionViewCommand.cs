﻿using ICSharpCode.Core;
using ICSharpCode.SharpDevelop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMOExplorer
{
	public class ShowSPDefinitionViewCommand : AbstractMenuCommand
	{
		public override void Run()
		{
			SD.Workbench.ShowView(new SPDefinitionViewContent());
		}
	}
}
